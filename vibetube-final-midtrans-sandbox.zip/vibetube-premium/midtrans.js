
const midtransClient = require('midtrans-client');

function getSnap() {
  const snap = new midtransClient.Snap({
    isProduction: String(process.env.MIDTRANS_IS_PRODUCTION).toLowerCase() === 'true',
    serverKey: process.env.MIDTRANS_SERVER_KEY,
    clientKey: process.env.MIDTRANS_CLIENT_KEY
  });
  return snap;
}

module.exports = { getSnap };
