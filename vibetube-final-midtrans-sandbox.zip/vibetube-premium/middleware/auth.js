const jwt=require('jsonwebtoken');
module.exports=(req,res,next)=>{const t=req.headers.authorization?.replace('Bearer ','');if(!t)return res.status(401).json({error:'Login diperlukan'});try{req.user=jwt.verify(t,process.env.JWT_SECRET);next()}catch{return res.status(401).json({error:'Token tidak valid'})}};
