require('dotenv').config();const express=require('express'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),multer=require('multer'),crypto=require('crypto'),fs=require('fs'),path=require('path'),{execFile}=require('child_process'),rate=require('express-rate-limit'),db=require('./database'),auth=require('./middleware/auth');
const app=express(),PORT=process.env.PORT||3000,UPLOAD=path.join(__dirname,'uploads');fs.mkdirSync(UPLOAD,{recursive:true});app.use(express.json({limit:'2mb'}));
// ---------- Midtrans Sandbox payments ----------
app.post('/api/payments/create', auth, async (req, res) => {
  try {
    const { plan = 'monthly' } = req.body || {};
    const plans = {
      monthly: { name: 'VibeTube Premium Monthly', price: 49000 },
      yearly: { name: 'VibeTube Premium Yearly', price: 499000 }
    };
    const selected = plans[plan];
    if (!selected) return res.status(400).json({ error: 'Paket tidak valid' });
    const orderId = `VT-${Date.now()}-${req.user.id}`;
    const snap = getSnap();
    const transaction = await snap.createTransaction({
      transaction_details: { order_id: orderId, gross_amount: selected.price },
      item_details: [{ id: plan, price: selected.price, quantity: 1, name: selected.name }],
      customer_details: { email: req.user.email }
    });
    if (db.prepare) {
      try {
        db.prepare(`CREATE TABLE IF NOT EXISTS payments (
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, order_id TEXT UNIQUE,
          plan TEXT, amount INTEGER, status TEXT DEFAULT 'pending',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`).run();
        db.prepare('INSERT INTO payments(user_id,order_id,plan,amount) VALUES(?,?,?,?)')
          .run(req.user.id, orderId, plan, selected.price);
      } catch (_) {}
    }
    res.json({ orderId, token: transaction.token, redirect_url: transaction.redirect_url, amount: selected.price });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Gagal membuat pembayaran Midtrans' });
  }
});

app.post('/api/payments/notification', express.json(), async (req, res) => {
  try {
    const snap = getSnap();
    const status = await snap.transaction.notification(req.body);
    const orderId = status.order_id;
    const tx = status.transaction_status;
    const fraud = status.fraud_status;
    let finalStatus = 'pending';
    if (tx === 'capture' && fraud === 'accept' || tx === 'settlement') finalStatus = 'paid';
    else if (['cancel','deny','expire'].includes(tx)) finalStatus = 'failed';
    try {
      db.prepare('UPDATE payments SET status=? WHERE order_id=?').run(finalStatus, orderId);
    } catch (_) {}
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(400).json({ error: 'Invalid notification' });
  }
});

app.get('/api/payments/history', auth, (req, res) => {
  try {
    const rows = db.prepare('SELECT order_id,plan,amount,status,created_at FROM payments WHERE user_id=? ORDER BY id DESC').all(req.user.id);
    res.json(rows);
  } catch (_) { res.json([]); }
});

app.use(express.static('public'));app.use('/media',express.static(UPLOAD));app.use('/api/auth',rate({windowMs:15*60*1000,max:100}));
const storage=multer.diskStorage({destination:UPLOAD,filename:(r,f,cb)=>cb(null,crypto.randomBytes(16).toString('hex')+path.extname(f.originalname).toLowerCase())});const upload=multer({storage,limits:{fileSize:1024*1024*1024},fileFilter:(r,f,cb)=>cb(null,['video/mp4','video/webm','video/quicktime'].includes(f.mimetype))});
const token=u=>jwt.sign({id:u.id,username:u.username,role:u.role},process.env.JWT_SECRET,{expiresIn:'7d'});
app.post('/api/auth/register',(req,res)=>{try{let {username,email,password}=req.body;if(!username||!email||!password||password.length<8)return res.status(400).json({error:'Data tidak valid'});let hash=bcrypt.hashSync(password,12);let x=db.prepare('INSERT INTO users(username,email,password) VALUES(?,?,?)').run(username.trim(),email.trim().toLowerCase(),hash);let u=db.prepare('SELECT id,username,email,role FROM users WHERE id=?').get(x.lastInsertRowid);res.json({user:u,token:token(u)})}catch(e){res.status(409).json({error:'Username/email sudah digunakan'})}});
app.post('/api/auth/login',(req,res)=>{let u=db.prepare('SELECT * FROM users WHERE email=?').get(String(req.body.email||'').toLowerCase().trim());if(!u||!bcrypt.compareSync(req.body.password||'',u.password))return res.status(401).json({error:'Email atau password salah'});res.json({user:{id:u.id,username:u.username,email:u.email,role:u.role},token:token(u)})});
app.get('/api/videos',(req,res)=>{let q='%'+String(req.query.q||'')+'%',cat=req.query.category;let sql=`SELECT v.*,u.username,(SELECT count(*) FROM likes l WHERE l.video_id=v.id) likes FROM videos v JOIN users u ON u.id=v.user_id WHERE v.status='published' AND (v.title LIKE ? OR v.description LIKE ?)`;let p=[q,q];if(cat){sql+=' AND v.category=?';p.push(cat)}sql+=' ORDER BY v.created_at DESC LIMIT 100';res.json(db.prepare(sql).all(...p))});
app.get('/api/videos/:id',(req,res)=>{let v=db.prepare(`SELECT v.*,u.username,(SELECT count(*) FROM likes l WHERE l.video_id=v.id) likes FROM videos v JOIN users u ON u.id=v.user_id WHERE v.id=?`).get(req.params.id);if(!v)return res.sendStatus(404);res.json(v)});
app.post('/api/videos',auth,upload.single('video'),(req,res)=>{if(!req.file)return res.status(400).json({error:'Video wajib'});let title=String(req.body.title||'').trim(),category=String(req.body.category||'Umum');if(!title){fs.unlinkSync(req.file.path);return res.status(400).json({error:'Judul wajib'})}let thumb=req.file.filename+'.jpg';execFile('ffmpeg',['-y','-ss','00:00:01','-i',req.file.path,'-frames:v','1','-vf','scale=640:-2',path.join(UPLOAD,thumb)],()=>{});let x=db.prepare('INSERT INTO videos(user_id,title,description,category,filename,thumbnail,original_name,mimetype,size) VALUES(?,?,?,?,?,?,?,?,?)').run(req.user.id,title,req.body.description||'',category,req.file.filename,thumb,req.file.originalname,req.file.mimetype,req.file.size);res.json({id:x.lastInsertRowid})});
app.post('/api/videos/:id/like',auth,(req,res)=>{let x=db.prepare('SELECT 1 FROM likes WHERE user_id=? AND video_id=?').get(req.user.id,req.params.id);if(x)db.prepare('DELETE FROM likes WHERE user_id=? AND video_id=?').run(req.user.id,req.params.id);else db.prepare('INSERT INTO likes VALUES(?,?)').run(req.user.id,req.params.id);res.json({liked:!x})});
app.get('/api/videos/:id/comments',(req,res)=>res.json(db.prepare('SELECT c.*,u.username FROM comments c JOIN users u ON u.id=c.user_id WHERE video_id=? ORDER BY c.created_at DESC').all(req.params.id)));
app.post('/api/videos/:id/comments',auth,(req,res)=>{let body=String(req.body.body||'').trim();if(!body||body.length>1000)return res.status(400).json({error:'Komentar tidak valid'});db.prepare('INSERT INTO comments(user_id,video_id,body) VALUES(?,?,?)').run(req.user.id,req.params.id,body);res.json({ok:true})});
app.get('/api/users/:username',(req,res)=>{let u=db.prepare('SELECT id,username,created_at FROM users WHERE username=?').get(req.params.username);if(!u)return res.sendStatus(404);u.videos=db.prepare('SELECT * FROM videos WHERE user_id=? AND status="published" ORDER BY created_at DESC').all(u.id);res.json(u)});
app.get('/api/admin/videos',auth,(req,res)=>{if(req.user.role!=='admin')return res.sendStatus(403);res.json(db.prepare('SELECT v.*,u.username FROM videos v JOIN users u ON u.id=v.user_id ORDER BY v.created_at DESC').all())});
app.delete('/api/admin/videos/:id',auth,(req,res)=>{if(req.user.role!=='admin')return res.sendStatus(403);let v=db.prepare('SELECT * FROM videos WHERE id=?').get(req.params.id);if(v){for(const f of [v.filename,v.thumbnail])if(f&&fs.existsSync(path.join(UPLOAD,f)))fs.unlinkSync(path.join(UPLOAD,f));db.prepare('DELETE FROM videos WHERE id=?').run(req.params.id)}res.json({ok:true})});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public/index.html')));app.listen(PORT,()=>console.log('VibeTube http://localhost:'+PORT));
