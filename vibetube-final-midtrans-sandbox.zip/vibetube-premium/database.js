const Database=require('better-sqlite3');
const db=new Database('data/vibetube.db');
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE NOT NULL,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT DEFAULT 'user',created_at TEXT DEFAULT CURRENT_TIMESTAMP);CREATE TABLE IF NOT EXISTS videos(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL,title TEXT NOT NULL,description TEXT DEFAULT '',category TEXT NOT NULL,filename TEXT NOT NULL,thumbnail TEXT,original_name TEXT,mimetype TEXT,size INTEGER,views INTEGER DEFAULT 0,status TEXT DEFAULT 'published',created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));CREATE TABLE IF NOT EXISTS likes(user_id INTEGER,video_id INTEGER,PRIMARY KEY(user_id,video_id));CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY,user_id INTEGER,video_id INTEGER,body TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);`);
module.exports=db;
